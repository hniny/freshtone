

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="card">
        <div class="card-header">     
            <div class='col-md-12'>
                <div class="row justify-content-between">     
                <h4>Len Category</h4>             
                <a href="/len_categories/create" class='btn btn-sm btn-primary '>
                    <i class="fa fa-plus-circle" class='ml-1'></i>
                    Create</a>         
                </div>         
            </div>   
        </div>
        <div class="card-body">
            <table class="table table-bordered table-sm">
                <thead class="thead-dark">
                <tr>
                    <th scope="col" >#</th>
                    <th scope="col" >Category Name </th>
                    <th scope="col"  class='w-30'>Description</th>
                    <th scope="col" style="width:200px;" >Parent Category</th>
                    <th scope="col" style="width:114px;"> Action</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $len_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $len_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                    <tr>
                        <th scope="row"><?php echo e($n++); ?></th>
                        <td><?php echo e($len_category->category_name); ?></td>
                        <td><?php echo Str::limit($len_category->category_description,100); ?></td>
                        <td><?php echo e($len_category->getLenCategoryName($len_category->parent_category)); ?></td>
                        <td >
                            <a href="len_categories/<?php echo e($len_category->id); ?>"
                            class='btn btn-xs btn-primary'  >
                                <i class="fas fa-eye text-white"></i>
                            </a> 
                            <a href="len_categories/<?php echo e($len_category->id); ?>/edit"   class='btn btn-xs btn-warning'>
                            <i class="fas  fa-edit text-dark" aria-hidden="true"></i>
                            </a>
                            <form  class='d-inline' action="len_categories/<?php echo e($len_category->id); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button  type='submit' class='btn btn-xs btn-danger'>  
                                    <i class="fas fa-trash-alt text-white"></i> 
                                </button>      
                            </form>                              
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
                </tbody>
            </table>
        </div>
        <?php echo e($len_categories->appends(request()->input())->links()); ?>

   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/backend/len_category/index.blade.php ENDPATH**/ ?>