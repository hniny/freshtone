

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="container col-md-8 offset-md-2">
        <h1>Eye Mask</h1>   
    </div>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container col-md-8 offset-md-2">
    <form action="" >       
        <div class="form-group">
          <label for="exampleFormControlInput1">Title</label>
          <input type="text" class="form-control" name="title" value="<?php echo e($eye_mask->title); ?>">
        </div>            
        <div class="form-group">
            <label for="exampleFormControlSelect2">Eye Mask Content </label>
            <textarea class="form-control ml-0" name="category_description"
            id="exampleFormControlTextarea1" rows="3">
            <?php echo e($eye_mask->eye_mask_content); ?> 
            </textarea>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect2">Eye Mask Gallery </label>           
            <?php
                $gallery=json_decode($eye_mask->gallery);
            ?>  
            <br/>
            <div class="row">     
                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                    <div class="col-md-3 mb-2 ">     
                    <img src="<?php echo e(url('image/'.$value)); ?>" width="120px" height="120px" alt="">                       
                    </div>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>      
        </div>
        <div class="form-group">
            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-secondary">
                Back
            </a> 
        </div>      
      </form>  
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/eye_mask/show.blade.php ENDPATH**/ ?>