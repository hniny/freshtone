

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="container col-md-8 offset-md-2">
        <h1> Edit Accessory</h1>   
    </div>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container col-md-8 offset-md-2">
    <form action="<?php echo e(route('eye_masks.update',$eye_mask->id)); ?>" method="post" enctype="multipart/form-data">     
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
          <label for="exampleFormControlInput1">Title</label>
          <input type="text" class="form-control" name="title" value="<?php echo e($eye_mask->title); ?>">
        </div>            
        <div class="form-group">
            <label for="exampleFormControlSelect2">Accessory Content </label>
            <textarea class="form-control ml-0" name="accessory_content"
            id="exampleFormControlTextarea1" rows="3">
            <?php echo e($eye_mask->eye_mask_content); ?> 
            </textarea>
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect2">Accessory Gallery </label>  
                <div class="row">    
                    <?php
                        $gallery=json_decode($eye_mask->gallery);
                    ?> 
                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                        <div class="col-md-3 mb-2 ">     
                            <img src="<?php echo e(url('image/'.$value)); ?>" width="120px" height="120px" alt="no image">                       
                        </div>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </div>   
            <input type="hidden" value="<?php echo e($eye_mask->gallery); ?>" name="old_gallery" />         
            <input type="file" multiple name="gallery[]"  />
        </div>
        <div class="form-group">
            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-secondary">
                Back
            </a> 
            <button class='btn btn-primary'>Update</button>
        </div>      
      </form>  
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/eye_mask/edit.blade.php ENDPATH**/ ?>