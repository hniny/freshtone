<section class='link-bg-color '>     
    <div class="container">      
        <div class="row">
            <div class="col-md-12 mt-5 ">
                <h5 class='text-white '>Look Smarter See Better</h5>
                <h3 class='text-white'>CHOICE OF STARS</h3>
            </div>             
        </div>    
        <div class="row">              
            <div class="col-md-12 mb-5 "> 
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="row">
                            <div class="col-md-3 ">
                                <img src="vendors/images/color_lens7.jpg" class='slider-image' alt="...">
                                <div class='bg-white text-center bg slider-address'>
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p>  
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-3 flex">
                                <img src="vendors/images/color_lens8.jpg"  class='slider-image' alt="...">
                                <div class='bg-white text-center bg slider-address'  >
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p>  
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>                            
                            </div>
                            <div class="col-md-3">
                                <img src="vendors/images/color_lens9.jpg"  class='slider-image' alt="...">
                                <div class='bg-white text-center bg slider-address' >
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p>  
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <img src="vendors/images/color_lens10.jpg" class='slider-image' alt="...">
                                <div class='bg-white text-center bg slider-address'  >
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p> 
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>
                            </div>
                        </div>  
                    </div>
                    <div class="carousel-item">
                        <div class="row align-content-center">
                            <div class="col-md-3 ">
                                <img src="vendors/images/color_lens1.jpg"   alt="..." class='slider-image'>
                                <div class='bg-white text-center bg slider-address'  >
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p>  
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-3 flex">
                                <img src="vendors/images/color_lens2.jpg" class='slider-image'  alt="...">
                                <div class='bg-white text-center bg slider-address'   >
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p> 
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>                            
                            </div>
                            <div class="col-md-3">
                                <img src="vendors/images/color_lens3.jpg"  class='slider-image' alt="...">
                                <div class='bg-white text-center bg slider-address' >
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p> 
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <img src="vendors/images/color_lens10.jpg"  class='slider-image' alt="...">
                                <div class='bg-white text-center bg slider-address' >
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p>  
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>
                            </div>
                        </div> 
                    </div>
                    <div class="carousel-item">
                        <div class="row ">
                            <div class="col-md-3">
                                <img src="vendors/images/color_lens16.jpg"  class='slider-image' alt="...">
                                <div class='bg-white text-center bg slider-address' >
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p>  
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-3 flex">
                                <img src="vendors/images/color_lens6.jpg"  class='slider-image'  alt="...">
                                <div class='bg-white text-center bg slider-address' >
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p>  
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>                            
                            </div>
                            <div class="col-md-3">
                                <img src="vendors/images/color_lens3.jpg" class='slider-image' alt="...">
                                <div class='bg-white text-center bg slider-address'  >
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p>  
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <img src="vendors/images/color_lens1.jpg" class='slider-image' alt="...">
                                <div class='bg-white text-center bg slider-address'  >
                                    <i>Thoom Thoom</i>
                                    <p>@ Thoom Thoom</p>
                                    <p>  
                                        <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                        <i class="fa fa-instagram ml-2 icon" aria-hidden="true"></i>
                                        <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                        <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                    </p>
                                </div>
                            </div>
                        </div>  
                    </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">                       
                        <i class="fa fa-arrow-left left-icon" aria-hidden="true"></i>                                          
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">                        
                      <i class="fa fa-arrow-right right-icon" aria-hidden="true"></i>                       
                    </a>     
                     
                </div>
            </div>
        </div>       
    </div>       
</section><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/frontend/star.blade.php ENDPATH**/ ?>