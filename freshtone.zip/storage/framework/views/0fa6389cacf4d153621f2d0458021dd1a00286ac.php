

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-dark">
        <div class="container  ">
            <div class='row   justify-content-between'>    
               Accessory  
                <a href="/accessories" class="btn btn-primary">
                   Back
               </a>        
             </div>
           </div>  
    </div>
    <div class="card-body">
        <form action="" >  
            <div class="form-group">
              <label for="exampleFormControlInput1">Accessory Category</label>
              <input type="text" class="form-control bg-white" readonly name="title" value="<?php echo e($accessory->accessoryCategory->name); ?>">
            </div>      
            <div class="form-group">
              <label for="exampleFormControlInput1">Title</label>
              <input type="text" class="form-control" name="title" value="<?php echo e($accessory->title); ?>">
            </div>            
            <div class="form-group">
                <label for="exampleFormControlSelect2">Accessory Content </label>
                <textarea class="description" name="description"
                id="exampleFormControlTextarea1" rows="3">
                <?php echo e($accessory->description); ?> 
                </textarea>
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect2">Accessory Gallery </label>           
                <?php
                    $gallery=json_decode($accessory->gallery);
                ?>  
                <br/>
                <div class="row">     
                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>                     
            </div>         
        </form>  
    </div>
</div>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> 
        $(document).ready(function(){
            $('.description').summernote();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/backend/accessory/show.blade.php ENDPATH**/ ?>