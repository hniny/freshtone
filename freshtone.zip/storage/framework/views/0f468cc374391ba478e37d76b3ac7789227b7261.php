
<?php $__env->startSection('title','Freshtone'); ?>
<?php $__env->startSection('content'); ?>


    <!-- main slider -->
    <section>
        <div class="container-fluid m-0 p-0">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                  <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                  <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img class="d-block w-100" src="vendors/images/02.jpg" alt="First slide">                
                    <div class="carousel-caption d-none d-md-block">
                        <h3 class="animated  slideInDown  title" style="animation-delay: 1s;"> Welcome</h3>
                        <h5 class="animated fadeInLeft  main-title" style="animation-delay: 2s;"> FreshTone</h5>
                        <p class="animated fadeInRight sub" style="animation-delay: 3s;">Soft Cosmetic Lens</p>
                        <p class="animated zoomIn" style="animation-delay: 4s;">Premium Color Contact Lens From KOREA</p>
                        <p class="animated slideInUp slider-button" style="animation-delay: 5s;">
                            <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a></p>
                        <p class="animated slideInUp slider-button " style="animation-delay: 5s;">
                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>                            
                        </p> 
                    </div>   
                  </div>
                  <div class="carousel-item">
                    <img class="d-block w-100" src="vendors/images/banner9.jpg" alt="Second slide">                    
                    <div class="carousel-caption d-none d-md-block">
                        <h3 class="animated  slideInDown  title" style="animation-delay: 1s;"> Welcome</h3>
                        <h5 class="animated fadeInLeft  main-title" style="animation-delay: 2s;"> FreshTone</h5>
                        <p class="animated fadeInRight sub" style="animation-delay: 3s;">Soft Cosmetic Lens</p>
                        <p class="animated zoomIn" style="animation-delay: 4s;">Premium Color Contact Lens From KOREA</p>
                        <p class="animated slideInUp slider-button" style="animation-delay: 5s;">
                            <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a></p>
                        <p class="animated slideInUp slider-button " style="animation-delay: 5s;">
                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>                            
                        </p> 
                    </div>                    
                  </div>
                  <div class="carousel-item">
                    <img class="d-block w-100" src="vendors/images/banner6.jpg" alt="Third slide">                   
                    <div class="carousel-caption d-none d-md-block">
                        <h3 class="animated  slideInDown  title" style="animation-delay: 1s;"> Welcome</h3>
                        <h5 class="animated fadeInLeft  main-title" style="animation-delay: 2s;"> FreshTone</h5>
                        <p class="animated fadeInRight sub" style="animation-delay: 3s;">Soft Cosmetic Lens</p>
                        <p class="animated zoomIn" style="animation-delay: 4s;">Premium Color Contact Lens From KOREA</p>
                        <p class="animated slideInUp slider-button" style="animation-delay: 5s;">
                            <a href="#" >See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                        </p>
                        <p class="animated slideInUp slider-button " style="animation-delay: 5s;">
                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>                            
                        </p> 
                    </div> 
                  </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </section>
    <!--end main slider -->
    <!-- accessory -->
    <section>
        <div class="container pt-5 pb-5 ">
            <div class="row ">
                <div class="col-md-4 col-sm-12" >
                    <div class='card border-0 collection' style="width: 20rem;">
                        <div class="row bg-light">
                            <div class="col-md-7 mt-5 ">
                            New Collection<br/>
                            <h4 class='text-info'>Accessories</h4>
                            <p class="slider-button  mt-2 align-content-center" >
                                <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                            </p>  

                            </div>
                            <div class="col-md-5">                               
                                <img src="vendors/images/accessores2.jpg" alt="" style='width: 150px;height:155px; ' srcset="">                               
                            </div>
                        </div>
                    </div>     
                    
                </div>
                

                <div class="col-md-4 col-sm-12">
                    <div class='card border-0 ' style="width: 20rem;">
                        <div class="row bg-light">
                            <div class="col-md-7 mt-5">
                            Fresh Tone<br/>
                            <h4 class='text-info'>Eye  Mask</h4>
                            <p class="slider-button  mt-2 align-content-center" >
                                <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                                </p>  
                            </div>
                            <div class="col-md-5">                               
                                <img src="vendors/images/accessores2.jpg" alt="" style='width: 150px;height:155px; ' srcset="">                               
                            </div>
                        </div>
                    </div>      
                </div>
                
                <div class="col-md-4 col-sm-12">
                    <div class='card border-0 ' style="width: 21rem;">
                        <div class="row bg-light">
                            <div class="col-md-7 mt-5">
                                Fresh Tone<br/>
                                <h4 class='text-info'>Eye Care</h4>
                            <p class="slider-button  mt-2 align-content-center" >
                                <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                                </p>  
                            </div>
                            <div class="col-md-5">                               
                                <img src="vendors/images/accessores2.jpg" alt="" style='width: 150px;height:155px; ' srcset="">                               
                            </div>
                        </div>
                    </div>      
                </div>
                
            </div>
        </div>
    </section>
    <!-- end accessory -->

    
    <section class='newcollection-color''>
        <div class="p-5">
        <div class="container p-5 bg-white">   
            <h4>New Collection</h4>  
            <div class="row">
                <div class="col-md-12" >
                <span class='text-black-50 font-weight-bold' >CONTACT LENS</span>   
                <span class='float-right'>
                    <nav class="navbar navbar-expand-lg navbar-light "
                    style='height: 60px;'>
                        <a class="navbar-brand sub-item" href="#">Color</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse collapse-link" id="navbarNavAltMarkup">
                            <div class="navbar-nav ">
                            <a class="nav-item nav-link sub-item" href="#">Power </a>
                            <a class="nav-item nav-link sub-item" href="#">Clear Power</a>
                            <a class="nav-item nav-link sub-item" href="#">Daily</a>
                                
                            </div>
                        </div>
                    </nav>
                </span>         
                </div>               
            </div>            
            <div id="carouselExampleFade" class="carousel slide carousel-fade"  data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="row">
                            <div class="col-md-3">
                            <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens6.jpg" alt="Card image cap">
                                    <div class="card-body ">
                                        <div  class='circle' style="background-color:gray;"> &nbsp;&nbsp;</div> 
                                    <span >
                                        Diamond Gray                     
                                    </span>
                                    <h4 class='text-center text-info'>$ 15.00</h4>
                                    <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                    <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                            </div>                  
                            </div>
                            <div class="col-md-3">
                                <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens2.jpg" alt="Card image cap">                       
                                    <div class="card-body ">
                                        <span  class='circle' style="background-color:cornflowerblue;"> &nbsp;&nbsp;</span> 
                                    <span >
                                        Diamond Brown                     
                                    </span>
                                    <h4 class='text-center text-info'>$ 15.00</h4>
                                    <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                    <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                            </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens8.jpg" alt="Card image cap">
                                    <div class="card-body ">
                                        <span  class='circle'  style="background-color:rgb(207, 100, 166);"> &nbsp;&nbsp;</span> 
                                    <span >
                                        Crystal Pink                
                                    </span>
                                    <h4 class='text-center text-info'>$ 15.00</h4>
                                    <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                    <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                            </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens9.jpg" alt="Card image cap">
                                    <div class="card-body ">
                                        <span  class='circle'  style="background-color:blue;"> &nbsp;&nbsp;</span> 
                                    <span >
                                        Crystal Blue                    
                                    </span>
                                    <h4 class='text-center text-info'>$ 15.00</h4>
                                    <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                    <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                            </div>
                            </div>                          
                        </div>     
                        <div class="row mt-3 ">
                            <div class="col-md-12 " style='margin-left:44%;'>
                                <p class="slider-button  mt-2 " >
                                    <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                                </p>  
                            </div>
                        </div>          
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-md-3">
                            <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens11.jpg" alt="Card image cap">
                                    <div class="card-body ">
                                        <div  class='circle' style="background-color:gray;"> &nbsp;&nbsp;</div> 
                                    <span >
                                        Diamond Gray                     
                                    </span>
                                    <h4 class='text-center text-info'>$ 15.00</h4>
                                    <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                    <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                            </div>                  
                            </div>
                            <div class="col-md-3">
                                <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens12.jpg" alt="Card image cap">                       
                                    <div class="card-body ">
                                        <span  class='circle' style="background-color:cornflowerblue;"> &nbsp;&nbsp;</span> 
                                    <span >
                                        Diamond Brown                     
                                    </span>
                                    <h4 class='text-center text-info'>$ 15.00</h4>
                                    <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                    <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                            </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens13.jpg" alt="Card image cap">
                                    <div class="card-body ">
                                        <span  class='circle'  style="background-color:rgb(207, 100, 166);"> &nbsp;&nbsp;</span> 
                                    <span >
                                        Crystal Pink                
                                    </span>
                                    <h4 class='text-center text-info'>$ 15.00</h4>
                                    <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                    <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                            </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens15.jpg" alt="Card image cap">
                                    <div class="card-body ">
                                        <span  class='circle'  style="background-color:blue;"> &nbsp;&nbsp;</span> 
                                    <span >
                                        Crystal Blue                    
                                    </span>
                                    <h4 class='text-center text-info'>$ 15.00</h4>
                                    <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                    <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                            </div>
                            </div>                          
                        </div>     
                        <div class="row mt-3 ">
                            <div class="col-md-12 " style='margin-left:44%;'>
                                <p class="slider-button  mt-2 " >
                                    <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a></p>  
                            </div>
                        </div>     
                    </div>
                    <div class="carousel-item">
                        <div class="row">
                            <div class="col-md-3">
                            <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens6.jpg" alt="Card image cap">
                                    <div class="card-body ">
                                        <div  class='circle' style="background-color:gray;"> &nbsp;&nbsp;</div> 
                                    <span >
                                        Diamond Gray                     
                                    </span>
                                    <h4 class='text-center text-info'>$ 15.00</h4>
                                    <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                    <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                            </div>                  
                            </div>
                            <div class="col-md-3">
                                <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens16.jpg" alt="Card image cap">                       
                                    <div class="card-body ">
                                        <span  class='circle' style="background-color:cornflowerblue;"> &nbsp;&nbsp;</span> 
                                    <span >
                                        Diamond Brown                     
                                    </span>
                                    <h4 class='text-center text-info'>$ 15.00</h4>
                                    <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                    <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                            </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens8.jpg" alt="Card image cap">
                                    <div class="card-body ">
                                        <span  class='circle'  style="background-color:rgb(207, 100, 166);"> &nbsp;&nbsp;</span> 
                                        <span >
                                            Crystal Pink                
                                        </span>
                                        <h4 class='text-center text-info'>$ 15.00</h4>
                                        <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                        <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card slider-card">                   
                                    <img class="card-img-top" src="vendors/images/color_lens9.jpg" alt="Card image cap">
                                    <div class="card-body ">
                                        <span  class='circle'  style="background-color:blue;"> &nbsp;&nbsp;</span> 
                                        <span>
                                            Crystal Blue                    
                                        </span>
                                        <h4 class='text-center text-info'>$ 15.00</h4>
                                        <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                        <span> PWR  : -0.00 to -8.00</span> 
                                    </div>                     
                                </div>
                            </div>                          
                        </div>     
                        <div class="row mt-3 ">
                            <div class="col-md-12" style='margin-left:44%;'>
                                <p class="slider-button  mt-2 " >
                                    <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a></p>  
                            </div>
                        </div>   
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">              
                    <i class="fa fa-arrow-left left-link-icon" aria-hidden="true"></i>
                </a>
                <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">                            
                <i class="fa fa-arrow-right right-link-icon" aria-hidden="true"></i>                       
                </a>
            </div>           
        </div>
        </div>
    </section>
    

    <!-- fresh tone  -->
    <section class='mt-4'>
        <div class="container-fluid "  style='height: 430px;'>
            <div class="row"  >
                <div class="col-md-1"></div>
                <div class="col-md-4" >
                <img src="vendors/images/color_lens6.jpg"  alt="" style='left: -10px;width:104%;' class='one'>                            
                    <img src="vendors/images/color_lens1.jpg" alt=""  class='two'
                    >                                         
                </div>               
                <div class="col-md-7  col-sm-12" style='margin-top: 11px;background-color: #E9F7F8;'>
                    <div class='ml-3 mt-3'>   
                        <h3 class='text-info font-weight-bold'>Fresh Tone</h3>
                        
                        <h5 class='text-info '>Discover The Secret Of Charm & Confidence</h5>
                        <p class='text-lowercase'>FRESHTONE CONTACT LENS ARE A WORLDWIDE WELL KNOWN BRAND WHICH DOES NOT NEED ANY INTRODUCTION OUR MOTIVE IS QUALITY FIRST WE DO NOT LET OUR CUSTOMER COMPROMISE WITH THEIR HEALTH OUR LENSES ARE MADE IN SOUTH KOREA UNDER STRICT GUIDANCE AND OUR PRODUCT IS ISO, GMP AND FDA APPROVED.</p>
                        <p class="slider-button  mt-2 align-content-center" >
                            <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                        </p>  
                        <p></p>
                        <br/>
                        <br/><br/>
                        <br/><br/><br/><br/>
                        <br/> 
                        <br/>
                        <br/>             
                    </div>                 
                </div>
            </div>           
        </div>
    </section>
    <!-- end fresh tone -->

    <!-- safety and confornt   -->
    <section class='mt-5'>
        <div class="container-fluid mt-5 mb-5 "  style='height: 100%;'>
            <div class="row">
                <div class="col-md-1 safety-bg-color"></div>      
                <div class="col-md-7 col-sm-12  safety-bg-color" style="margin-left: -33px;">                      
                    <div class='ml-3 mt-5'>   
                        <h3 class='text-info title-color'>
                            SAFETY & COMFORT
                        </h3>                                     
                        <p class='text-lowercase'>                           
                            FRESHTONE CONTACT LENSES INCORPORATE COLOR SANDWICH PROCESSING TECHNOLOGY ENSURING THAT THE COLORED LAYER IS COMPLETELY COATED WITHIN THE LENS THIS PREVENTS DIRECT CONTACT WITH THE EYES ENSURING SAFETY, COMFORT AND EASE OF USE THE LENS ARE SHAPED TO LET THE NATURAL MOISTURE PRODUCED IN THE EYE DIVIDE AND FLOW OVER THE LENS SURFACE EVENLY, PROVIDING ALL DAY COMFORT THE COLORED PORTION OF THE LENS IS PROPORTIONED TO PERFECTION AND ITS STRUCTURE ALLOW THE LENS TO RADIATE A BRIGHTER AND MORE NATURAL LOOK WHILE NOT AFFECTING CLARITY OF THE SIGHT.
                        </p>
                        <ul style="list-style-type: none;">
                            <li class='text-lowercase'><i class="fa fa-eye" aria-hidden="true"></i>
                                SOFT CONTACT LENSES ARE BEST FOR DRY EYES
                            </li>
                            <li class='text-lowercase'><i class="fa fa-eye" aria-hidden="true"></i>
                                WATER CONTENT MAKES A DIFFERENCE
                            </li>
                        </ul>
                        <p class="slider-button  mt-2 align-content-center" >
                            <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                        </p>  
                        <br/>
                        <br/><br/>
                        <br/><br/><br/>                                          
                    </div>                 
                </div>               
                <div class="col-md-3 col-sm-12" >
                <img src="vendors/images/certi_fi.jpg" height="100%" width="100%" alt="" srcset="" class='one'>                            
                </div>   
            </div>           
        </div>
    </section>
    <!-- end  safety and confornt -->
    
    <!-- video slider -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-12 ">
                    <h5 class='text-black' >Contact Lens</h5>
                    <h3 class='text-black'>WEARING GUIDES</h3>                    
                </div>
            </div>  
            <div class="row">              
                    <div class="owl-carousel owl-theme">  
                        <div class="col-md-4  col-sm-12">
                            <div class="item-video" data-merge="1">                 
                                <a class="owl-video" href="https://www.youtube.com/watch?v=9NHLfLbNWjc&feature=emb_logo"></a>
                                <p class='text-white mt-1 ml-2'>
                                    <i class="fa fa-video-camera" aria-hidden="true"></i>
                                    How to use contact lens
                                </p> 
                            </div>
                        </div>  
                        <div class="col-md-4  col-sm-12">
                            <div class="item-video" data-merge="1">
                    
                                <a class="owl-video" href="https://www.youtube.com/watch?v=OfrQ1hm1dRA&feature=emb_logo"></a>
                                <p class='text-white mt-1 ml-2'>
                                    <i class="fa fa-video-camera" aria-hidden="true"></i>
                                    How to use contact lens
                                </p>
                        
                            </div>
                        </div>   
                        <div class="col-md-4  col-sm-12">
                            <div class="item-video" data-merge="1">
                                <a class="owl-video" href="https://www.youtube.com/watch?v=YoPrX540Qnw"></a>
                                <p class='text-white mt-1 ml-2'>
                                    <i class="fa fa-video-camera" aria-hidden="true"></i>
                                    How to use contact lens
                                </p>
                            </div>
                        </div>      
                        <div class="col-md-4  col-sm-12">
                            <div class="item-video" data-merge="1">
                                <a class="owl-video " href="https://www.youtube.com/watch?v=ontrHkt97uw"></a>
                                <p class='text-white mt-1 ml-2'>
                                    <i class="fa fa-video-camera" aria-hidden="true"></i>
                                    How to use contact lens
                                </p>
                            </div>
                        </div>            
                        
                        <div class="col-md-4 col-sm-12">
                            <div class="item-video" data-merge="1">
                                <a class="owl-video " href="https://www.youtube.com/watch?v=WzRCKtXmzVE&feature=emb_logo"></a>
                                <p class='text-white mt-1 ml-2'>
                                    <i class="fa fa-video-camera" aria-hidden="true"></i>
                                    How to use contact lens
                                </p>
                            </div> 
                        </div>
                </div>
            </div>          
            
            
        </div>
    </section>
    <!-- end video slider -->

    
    <section class='link-bg-color '>     
        <div class="container">      
            <div class="row">
                <div class="col-md-12 mt-5 ">
                    <h5 class='text-white '>Look Smarter See Better</h5>
                    <h3 class='text-white'>CHOICE OF STARS</h3>
                </div>             
            </div>    
            <div class="row">              
                <div class="col-md-12 mb-5 "> 
                    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="row">
                                <div class="col-md-3 ">
                                    <img src="vendors/images/color_lens7.jpg" class='slider-image' alt="...">
                                    <div class='bg-white text-center bg slider-address'>
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p>  
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-3 flex">
                                    <img src="vendors/images/color_lens8.jpg"  class='slider-image' alt="...">
                                    <div class='bg-white text-center bg slider-address'  >
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p>  
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>                            
                                </div>
                                <div class="col-md-3">
                                    <img src="vendors/images/color_lens9.jpg"  class='slider-image' alt="...">
                                    <div class='bg-white text-center bg slider-address' >
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p>  
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <img src="vendors/images/color_lens10.jpg" class='slider-image' alt="...">
                                    <div class='bg-white text-center bg slider-address'  >
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p> 
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>
                                </div>
                            </div>  
                        </div>
                        <div class="carousel-item">
                            <div class="row align-content-center">
                                <div class="col-md-3 ">
                                    <img src="vendors/images/color_lens1.jpg"   alt="..." class='slider-image'>
                                    <div class='bg-white text-center bg slider-address'  >
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p>  
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-3 flex">
                                    <img src="vendors/images/color_lens2.jpg" class='slider-image'  alt="...">
                                    <div class='bg-white text-center bg slider-address'   >
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p> 
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>                            
                                </div>
                                <div class="col-md-3">
                                    <img src="vendors/images/color_lens3.jpg"  class='slider-image' alt="...">
                                    <div class='bg-white text-center bg slider-address' >
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p> 
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <img src="vendors/images/color_lens10.jpg"  class='slider-image' alt="...">
                                    <div class='bg-white text-center bg slider-address' >
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p>  
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>
                                </div>
                            </div> 
                        </div>
                        <div class="carousel-item">
                            <div class="row ">
                                <div class="col-md-3">
                                    <img src="vendors/images/color_lens16.jpg"  class='slider-image' alt="...">
                                    <div class='bg-white text-center bg slider-address' >
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p>  
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-3 flex">
                                    <img src="vendors/images/color_lens6.jpg"  class='slider-image'  alt="...">
                                    <div class='bg-white text-center bg slider-address' >
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p>  
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>                            
                                </div>
                                <div class="col-md-3">
                                    <img src="vendors/images/color_lens3.jpg" class='slider-image' alt="...">
                                    <div class='bg-white text-center bg slider-address'  >
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p>  
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <img src="vendors/images/color_lens1.jpg" class='slider-image' alt="...">
                                    <div class='bg-white text-center bg slider-address'  >
                                        <i>Thoom Thoom</i>
                                        <p>@ Thoom Thoom</p>
                                        <p>  
                                            <i class="fa fa-facebook-official " aria-hidden="true"></i>
                                            <i class="fa fa-instagram ml-2 icon" aria-hidden="true"></i>
                                            <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                                            <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                                        </p>
                                    </div>
                                </div>
                            </div>  
                        </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">                       
                            <i class="fa fa-arrow-left left-icon" aria-hidden="true"></i>                                          
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">                        
                        <i class="fa fa-arrow-right right-icon" aria-hidden="true"></i>                       
                        </a>     
                        
                    </div>
                </div>
            </div>       
        </div>       
    </section>
     
    
 <!-- contact -->
 <section class='mt-3'>
    <div class="container">
        <div class="row " >
            <div class="col-md-5 mt-2">                   
                <ul style='list-style-type:none;margin-left: -53px;'>
                    <li> <h5>CONTACT</h5></li>
                    <li>
                        <i class="fa fa-address-book" aria-hidden="true"></i>
                        No.(121), 1st Floor, Corner of Thein Phyu Rd. and Merchant Rd., (Opposite of Myanmar Five Star Line), Botahtaung Tsp., Yangon Myanmar.
                    </li>
                    <li>
                        <i class="fa fa-mobile" aria-hidden="true">
                            +959 5152274
                        </i>
                    </li>
                    <li>
                        <i class="fa fa-envelope" aria-hidden="true"></i>                           
                        freshtone.myanmar@gmail.com
                    </li>
                    <li></li>
                </ul>
                <p style="margin-left: 2.5rem;">
                     <i class="fa fa-facebook-official " aria-hidden="true"></i>
                    <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                    <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                    <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                </p>                  
            </div>
            <div class="col-md-3  mt-2">
                <ul style='list-style-type:none;'>
                    <li> <h5>QUICK LINK</h5></li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>
                        <a href="#"> Home</a>
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>
                        <a href="#"> Contact Lens</a>
                            
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>                          
                        <a href="#"> Accessories</a>
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>                          
                        <a href="#"> Eye Mask</a>
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>                          
                        <a href="#"> Eye Care</a>
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>                          
                        <a href="#"> Safety</a>
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>                          
                        <a href="#"> Contact Us</a>
                    </li>                       
                </ul>
            </div>
            <div class="col-md-4 m-0 p-0 mt-2">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3820.09447236042!2d96.16486161423276!3d16.771974788450123!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c1ed4c2195b60d%3A0x790bedd11a54b370!2sFreshToneMyanmar!5e0!3m2!1sen!2smm!4v1581305963661!5m2!1sen!2smm" width="100%" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            </div>
        </div>
    </div>
 </section>
<!-- end contact  -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/frontend/home.blade.php ENDPATH**/ ?>