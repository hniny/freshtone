

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
   <div class="container">      
        <div class='col-md-12'>  
         <div class="row justify-content-between">               
           <h4>Len Item</h4>             
           <a href="/len_items/create" class='btn btn-sm btn-primary '>
            <i class="fa fa-plus-circle" class='ml-1'></i>
            Create</a>   
        </div>      
       </div>  
   </div>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container">
    <table class="table table-bordered">
        <thead class="thead-dark">
          <tr>
            <th scope="col" >#</th>
            <th scope="col"> Len Item Category</th>
            <th scope="col" >Item Name </th>
            <th scope="col" >Price</th>
            <th scope="col"  style="width: 340px;" >Description</th>
            <th scope="col" style="width: 110px;">Item Image</th>
            <th scope="col" style="width:114px;"> Action</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $len_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $len_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
            <tr>
                <th scope="row"><?php echo e($n++); ?></th>
                <td><?php echo e($len_item->lenCategory->category_name); ?></td>
                <td><?php echo e($len_item->item_name); ?></td>
                <td><?php echo e($len_item->price); ?></td>
                <td><?php echo e(Str::limit($len_item->description,100)); ?></td>
                <td>
                    <img src="image/<?php echo e($len_item->item_image); ?>"  width="60px" height="50px"
                    data-toggle="modal" data-target="#exampleModal<?php echo e($len_item->id); ?>"/>
                    <div class="modal fade" id="exampleModal<?php echo e($len_item->id); ?>" style="top: 20%;" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document" style='width: 340px;' >
                        <div class="modal-content text-center">  
                                      
                            <div class="modal-body">
                            <img src="<?php echo e(url('image/'.$len_item->item_image)); ?>" data-src="<?php echo e($len_item->item_image); ?>"  width="300px"  height="230px" id="item_image" data-toggle="modal" data-target="#exampleModal"/>  
                            </div>   
                            <button type="button" style="margin-bottom: 15px;" class="close close-button"   data-dismiss="modal" aria-label="Close">
                                <i class="fa fa-times-circle"   aria-hidden="true"></i>
                            </button>             
                        </div>
                        </div>
                    </div>    
                </td>               
                <td>
                    <a href="len_items/<?php echo e($len_item->id); ?>"
                    class='btn btn-sm'  >
                        <i class="fas fa-eye text-success"></i>
                    </a> 
                    <a href="len_items/<?php echo e($len_item->id); ?>/edit" >
                    <i class="fas  fa-edit text-dark" aria-hidden="true"></i>
                    </a>
                    <form  class='d-inline' action="len_items/<?php echo e($len_item->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button  type='submit' class='btn btn-sm '>  
                             <i class="fas fa-trash-alt text-danger"></i> 
                        </button>      
                    </form>                              
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
        </tbody>
    </table>
    <?php echo e($len_items->appends(request()->input())->links()); ?>

   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="vendors/css/style.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/len_item/index.blade.php ENDPATH**/ ?>