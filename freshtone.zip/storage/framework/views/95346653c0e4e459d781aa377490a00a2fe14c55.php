

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>  
     <div class="card">
       <div class="card-header bg-dark">
        Create Accessory Category
       </div>
       <div class="card-body">
        <form action="/accessory_categories"  method="post" class="needs-validation" novalidate>
          <?php echo csrf_field(); ?>            
          <div class="form-group">
            <label for="exampleFormControlInput1"> Accessory Category Name</label>
            <input type="text" class="form-control" name="name" required>
            <div class="invalid-feedback">
              Enter  Accessory category name
            </div> 
          </div>          
          <div class="form-group">           
                <a href="/accessory_categories" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn btn-primary">Save</button>           
          </div>
        </form> 
       </div>
     </div>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>    
<script src="<?php echo e(asset('vendors/js/validation.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/backend/accessory_category/create.blade.php ENDPATH**/ ?>