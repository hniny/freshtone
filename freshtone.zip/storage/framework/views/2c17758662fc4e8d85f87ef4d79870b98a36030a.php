
<section > 
    <div class="container  p-3" >          
        <div class="row ">
            <div class="col-md-4 col-sm-4 header-width">
                <div class='d-flex'> 
                    <div class="p-2 text">
                        <button class='bg-primary phone-button border-0 btn btn-md' style="border-radius: 50%;">
                            <i class="fa fa-mobile phone-logo rounded-circle text-white" aria-hidden="true" ></i>              
                        </button>
                    </div>
                    <div class="p-2 text">
                        <span class='title-color'>CALL US ON</span><br/>
                        <span>09-965152274</span>                             
                    </div>                           
                </div>                  
            </div>
            <div class="col-md-4 col-sm-4 text-center header-width">
                <img src="vendors/images/logo002.png" alt="logo"  class='image-logo'>
            </div>
            <div class="col-md-4 col-sm-4 header-width">                
                <div class="d-flex float-right">  
                    <div class="p-2">  
                        <button class='bg-primary text-center cart-button  border-0 btn btn-md' style="border-radius: 50%;">                    
                        <i class="fa fa-shopping-basket cart-logo" aria-hidden="true" ></i>          
                        </button>  
                        <span class="badge bg-danger text-white cart-count" style='border-radius: 20px;'>10</span>
                    </div>
                    <div class="p-2 text"> <span class='title-color'>MY CARD</span><br/>
                        <span >8 MILE $0.00</span>   
                    </div>
                </div>                   
            </div>                  
        </div> 
    </div>         
</section>
<!-- end header -->

<!-- nav -->   
<section class="nav-background">     
    <div class="container ">        
        <nav class="navbar navbar-expand-lg navbar-light offset-md-2" style="margin-bottom: 0px;">     
            <a class="navbar-brand" href="/">HOME</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ">                           
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">CONTACT LENS</a>
                        <div class="dropdown-menu">
                        <a class="dropdown-item" href="/color">COLOR CONTENT LENS</a>
                        <a class="dropdown-item" href="#two">POWER CONTENT LENS</a>
                        <div role="separator" class="dropdown-divider">CLEAR POWER LENS</div>
                        <a class="dropdown-item" href="#three">DAILY CONTACT LENS</a>
                        </div>
                    </li>                
                    <li class="nav-item ">
                        <a class="nav-link" href="#mdo">ACCESSORIES</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#fat">EYE MASK</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#mdo">EYE CARE</a>
                    </li>
                    <li class="nav-item">
                        <a  href="/safety" class="nav-link" href="#fat">SAFETY</a>
                    </li>
                    <li class="nav-item">
                        <a href="/contact" class="nav-link" href="#mdo">CONTACT US</a>
                    </li>
                </ul>            
            </div>        
        </nav>
    </div>         
</section>
<!-- end nav -->

<?php /**PATH E:\hmm\freshtone\freshtone\resources\views/frontend/header.blade.php ENDPATH**/ ?>