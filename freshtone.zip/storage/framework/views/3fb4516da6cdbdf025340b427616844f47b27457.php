

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="container">      
            <div class='col-md-12  '>   
                <div class="row justify-content-between">
                    <h4>Accessories</h4>             
                    <a href="/accessories/create" class='btn btn-sm btn-primary '>
                    <i class="fa fa-plus-circle" class='ml-1'></i>
                    Create</a>   
                </div>
            </div>     
       </div>   
    </div>
    <div class="card-body">
        <table class="table table-bordered table-sm">
            <thead class="thead-dark">
              <tr>
                <th scope="col" >#</th>
                <th scope="col"> Accesory Category</th>
                <th scope="col" >Title </th>
                <th scope="col"  style="width: 500px;">Description</th>
                
                <th scope="col" style="width:114px;"> Action</th>
              </tr>
            </thead>  
            <?php 
            $i=0;
           
          ?>    
          
            <tbody>
                <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    
                <tr>
                    <th scope="row"><?php echo e(++$i); ?></th>
                    <td><?php echo e($accessory->accessoryCategory->name); ?></td>
                    <td><?php echo e($accessory->title); ?></td>                  
                    <td>
                    <?php 
                        $text= html_entity_decode($accessory->description);
                    ?>
                        <?php echo substr(strip_tags($text), 0, 60); ?>

                    </td>              
                    <td >
                        <a href="accessories/<?php echo e($accessory->id); ?>"
                        class='btn btn-sm'  >
                            <i class="fas fa-eye text-success"></i>
                        </a> 
                        <a href="accessories/<?php echo e($accessory->id); ?>/edit" >
                        <i class="fas  fa-edit text-dark" aria-hidden="true"></i>
                        </a>
                        <form  class='d-inline' action="accessories/<?php echo e($accessory->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button  type='submit' class='btn btn-sm '>  
                                 <i class="fas fa-trash-alt text-danger"></i> 
                            </button>      
                        </form>                              
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
            </tbody>
        </table>
        <?php echo e($accessories->appends(request()->input())->links()); ?>

    </div>
</div> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/backend/accessory/index.blade.php ENDPATH**/ ?>