

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="container col-md-8 offset-md-2">
        <h1>Detail Len Category</h1>    
    </div>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container col-md-8 offset-md-2">
    <form action="" >       
        <div class="form-group">
          <label for="exampleFormControlInput1">Category Name</label>
          <input type="text" class="form-control" name="category_name" value="<?php echo e($lenCategory->category_name); ?>">
        </div>
        <div class="form-group">
            <label for="exampleFormControlSelect2">Select Parent Category</label>
            <select name="parent_category" class="form-control" id="exampleFormControlSelect2">
             <option value="0">Default </option> 
              <?php $__currentLoopData = $lenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $len_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($len_category->id); ?>"><?php echo e($len_category->category_name); ?></option>       
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </select>
        </div>      
        <div class="form-group">
            <label for="exampleFormControlTextarea1">Description</label>
            <textarea class="form-control ml-0" name="category_description"
            id="exampleFormControlTextarea1" rows="3">
            <?php echo e($lenCategory->category_description); ?> 
            </textarea>
        </div>
        <div class="form-group">
            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-secondary">
                Back
            </a> 
        </div>      
      </form>  
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/len_category/show.blade.php ENDPATH**/ ?>