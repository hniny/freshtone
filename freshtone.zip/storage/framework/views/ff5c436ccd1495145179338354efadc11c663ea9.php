

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
   <div class="container">
       <div class="row">         
           <h4>Eye Mask</h4>             
           <a href="<?php echo e(route('eye_masks.create')); ?>" style="margin-left: 888px;" class='btn btn-sm btn-primary'> Add New</a>         
       </div>  
   </div>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container">
    <table class="table table-bordered">
        <thead class="thead-dark">
          <tr>
            <th scope="col" >#</th>
            <th scope="col" >Title </th>
            <th scope="col" >Eye Mask Content </th>
            
            <th scope="col" style="width:114px;"> Action</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $eye_masks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eye_mask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
            <tr>
                <th scope="row"><?php echo e($n++); ?></th>
                <td><?php echo e($eye_mask->title); ?></td>
                <td><?php echo e($eye_mask->eye_mask_content); ?></td>
                
                <td >
                    <a href="eye_masks/<?php echo e($eye_mask->id); ?>"
                    class='btn btn-sm'  >
                        <i class="fas fa-eye text-success"></i>
                    </a> 
                    <a href="eye_masks/<?php echo e($eye_mask->id); ?>/edit" >
                    <i class="fas  fa-edit text-dark" aria-hidden="true"></i>
                    </a>
                    <form  class='d-inline' action="eye_masks/<?php echo e($eye_mask->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button  type='submit' class='btn btn-sm '>  
                             <i class="fas fa-trash-alt text-danger"></i> 
                        </button>      
                    </form>                              
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
        </tbody>
    </table>
    <?php echo e($eye_masks->appends(request()->input())->links()); ?>

   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/eye_mask/index.blade.php ENDPATH**/ ?>