

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-dark">
        Edit Accessory
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('accessories.update',$accessory->id)); ?>" method="post" enctype="multipart/form-data">     
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
              <label for="exampleFormControlInput1">Title</label>
              <input type="text" class="form-control" name="title" value="<?php echo e($accessory->title); ?>">
            </div>          
            <div class="form-group">
                <label for="exampleFormControlSelect2">Accessory Content </label>
                <textarea class="description" name="description"
                id="exampleFormControlTextarea1" >
                <?php echo e($accessory->description); ?> 
                </textarea>
            </div>
            <?php
                $gallery=json_decode($accessory->gallery);
            ?> 
            <div class="row mb-2">
                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group gallery">
                    <div class="col-sm-4 col-xs-6 col-md-3 col-lg-3">
                        <a class="thumbnail fancybox" href="/image/<?php echo e($value); ?>" rel="ligthbox">
                            <img class="img-responsive" alt="" width="200px" src="/image/<?php echo e($value); ?>" />                          
                        </a>      
                        <input type="hidden"   id="old<?php echo e($key); ?>"  data-old="<?php echo e($value); ?>" data-id="<?php echo e($accessory->id); ?>">              
                            
                        <a  id="close-icon" data-key="<?php echo e($key); ?>" class="close-icon btn btn-danger"><i class="fas fa-times"></i></a>
                        
                    </div>                
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <input type="hidden" value="<?php echo e($accessory->gallery); ?>" name="old_gallery" />    
            <div class="col-md-12 mb-2">                    
                <strong>Image:</strong>                       
                <input type="file" multiple name="gallery[]"  class="form-control"/>
            </div>               
            <div class="form-group">
                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-dark">
                    Back
                </a> 
                <button  type="submit" class='btn btn-primary'>Update</button>
            </div>      
        </form> 
    </div>
</div>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <style>
        .gallery{
            display: inline-block;
            margin-top: 20px;
        }
        .gallery img{
            width: 192px;
            height: 150px;
        }
        .close-icon{
            border-radius: 47%;
            position:absolute;
            right: -160px;
            top: -10px;
            padding: 2px 8px;
        }        
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> 
     $(document).ready(function(){
            $('.description').summernote();
            $(".fancybox").fancybox({
            openEffect: "none",
            closeEffect: "none"
            });
            $('.close-icon').on('click',function(){               
                var key=$(this).data('key');
                var old_image=$('#old'+key).data('old');
                var acc_id=$('#old'+key).data('id');
                window.location.href="/deleteImage?id="+acc_id+"&&old_image="+old_image;
                   
            });
     });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/backend/accessory/edit.blade.php ENDPATH**/ ?>