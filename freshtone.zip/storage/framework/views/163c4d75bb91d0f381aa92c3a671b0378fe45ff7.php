

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="container col-md-8 offset-md-2">
        <h1>Detail Len Item</h1>    
    </div>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container col-md-8 offset-md-2">
    <form action="" >       
        <div class="form-group">
          <label for="exampleFormControlInput1">Len Item Category</label>
          <input type="text" class="form-control" value="<?php echo e($len_item->lenCategory->category_name); ?>">
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Len Item </label>
            <input type="text" class="form-control"  value="<?php echo e($len_item->item_name); ?>">
        </div>
        <div class="form-group">
            <label for="exampleFormControlInput1">Price </label>
            <input type="text" class="form-control" value="<?php echo e($len_item->price); ?>">
        </div>
          
        <div class="form-group">
            <label for="exampleFormControlTextarea1">Description</label>
            <textarea class="form-control ml-0" 
            id="exampleFormControlTextarea1" rows="3">
            <?php echo e($len_item->description); ?> 
            </textarea>
        </div>
        <div class="form-group">         
            <label for="exampleFormControlTextarea1">Len Item Image</label>   
            <br/>
            <img src="<?php echo e(url('image/'.$len_item->item_image)); ?>" data-src="<?php echo e($len_item->item_image); ?>"  width="115px" height="100px"  id="item_image" data-toggle="modal" data-target="#exampleModal"/>                 
            <div class="modal fade" id="exampleModal" style="top: 20%;" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document" style='width: 340px;' >
                <div class="modal-content text-center">                                        
                    <div class="modal-body">
                    <img src="<?php echo e(url('image/'.$len_item->item_image)); ?>" data-src="<?php echo e($len_item->item_image); ?>"  width="300px"  height="230px" id="item_image" data-toggle="modal" data-target="#exampleModal"/>  
                    </div>   
                    <button type="button" class="close close-button"   data-dismiss="modal" aria-label="Close"    style="margin-bottom: 15px ;">
                        <i class="fa fa-times-circle"   aria-hidden="true"></i>
                    </button>             
                </div>
                </div>
            </div>            
        </div>
        <div class="form-group">
            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-secondary">
                Back
            </a> 
        </div>      
      </form>  
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="vendors/css/style.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/len_item/show.blade.php ENDPATH**/ ?>