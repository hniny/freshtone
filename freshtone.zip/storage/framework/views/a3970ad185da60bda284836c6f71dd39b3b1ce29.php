
<!-- footer -->
<section>
    <div class="container-fluid" style="background-color: #2D62A8;" >
        <div class="row">
            <div class="col-md-12">
                <p class='text-center text-white font-weight-bold p-3 mb-0'>
                    Copyright &#169; 2020 Company. All right reserved!
               </p>
            </div>
        </div>           
    </div>
</section>
<!-- end footer --> <?php /**PATH E:\hmm\freshtone\freshtone\resources\views/frontend/footer.blade.php ENDPATH**/ ?>