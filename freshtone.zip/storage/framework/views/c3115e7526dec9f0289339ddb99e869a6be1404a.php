

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="container col-md-8 offset-md-2">
    <h1>Create Accessories</h1>    
   </div>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container col-md-8 offset-md-2">
    <form action="/accessories" method="post"  
    enctype="multipart/form-data"
    class="needs-validation" novalidate>
        <?php echo csrf_field(); ?>     
          <div class="form-group">
          <label for="exampleFormControlSelect2">Select Accessory Category</label>
          <select id="accessory_category_id"  name="accessory_category_id" class="form-control"  required>
           <option value="0"> </option> 
            <?php $__currentLoopData = $accessory_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($accessory_category->id); ?>"><?php echo e($accessory_category->name); ?></option>       
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
          </select>
          <div class="invalid-feedback">
            Enter Accessory Category
          </div>
        </div>          
        <div class="form-group">
          <label for="exampleFormControlInput1">Title</label>
          <input type="text" class="form-control" name="title" required>
          <div class="invalid-feedback">
            Enter Title
          </div> 
        </div>
         
        <div class="form-group">
          <label for="exampleFormControlTextarea1">Description</label>       
          <textarea name="description" id="description" class="form-control" rows="5" cols="5" required></textarea>
          <div class="invalid-feedback">
            Enter Category Description
          </div>
        </div>
        <div class="form-group">
          <label for="exampleFormControlTextarea1">Accessory Image</label>    <br/>   
          <input type='file' name='gallery[]' id="gallery" multiple />
        </div>
        <div class="form-group">           
              <a href="/len_categories" class="btn btn-secondary">Cancel</a>
              <button type="submit" class="btn btn-primary">Save</button>           
        </div>
      </form>  
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<script src="<?php echo e(asset('vendors/js/validation.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/accessory/create.blade.php ENDPATH**/ ?>