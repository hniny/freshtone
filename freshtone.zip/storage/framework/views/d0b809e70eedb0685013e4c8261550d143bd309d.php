<section class='newcollection-color''>
    <div class="p-5">
      <div class="container p-5 bg-white">   
         <h4>New Collection</h4>  
         <div class="row">
             <div class="col-md-12" >
             <span class='text-black-50 font-weight-bold' >CONTACT LENS</span>   
             <span class='float-right'>
                 <nav class="navbar navbar-expand-lg navbar-light "
                 style='height: 60px;'>
                     <a class="navbar-brand sub-item" href="#">Color</a>
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                         <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse collapse-link" id="navbarNavAltMarkup">
                         <div class="navbar-nav ">
                         <a class="nav-item nav-link sub-item" href="#">Power </a>
                         <a class="nav-item nav-link sub-item" href="#">Clear Power</a>
                         <a class="nav-item nav-link sub-item" href="#">Daily</a>
                             
                         </div>
                     </div>
                 </nav>
             </span>         
             </div>               
         </div>            
         <div id="carouselExampleFade" class="carousel slide carousel-fade"  data-ride="carousel">
             <div class="carousel-inner">
                 <div class="carousel-item active">
                     <div class="row">
                         <div class="col-md-3">
                         <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens6.jpg" alt="Card image cap">
                                 <div class="card-body ">
                                     <div  class='circle' style="background-color:gray;"> &nbsp;&nbsp;</div> 
                                 <span >
                                     Diamond Gray                     
                                 </span>
                                 <h4 class='text-center text-info'>$ 15.00</h4>
                                 <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                 <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                         </div>                  
                         </div>
                         <div class="col-md-3">
                             <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens2.jpg" alt="Card image cap">                       
                                 <div class="card-body ">
                                     <span  class='circle' style="background-color:cornflowerblue;"> &nbsp;&nbsp;</span> 
                                 <span >
                                     Diamond Brown                     
                                 </span>
                                 <h4 class='text-center text-info'>$ 15.00</h4>
                                 <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                 <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                         </div>
                         </div>
                         <div class="col-md-3">
                             <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens8.jpg" alt="Card image cap">
                                 <div class="card-body ">
                                     <span  class='circle'  style="background-color:rgb(207, 100, 166);"> &nbsp;&nbsp;</span> 
                                 <span >
                                     Crystal Pink                
                                 </span>
                                 <h4 class='text-center text-info'>$ 15.00</h4>
                                 <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                 <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                         </div>
                         </div>
                         <div class="col-md-3">
                             <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens9.jpg" alt="Card image cap">
                                 <div class="card-body ">
                                     <span  class='circle'  style="background-color:blue;"> &nbsp;&nbsp;</span> 
                                 <span >
                                     Crystal Blue                    
                                 </span>
                                 <h4 class='text-center text-info'>$ 15.00</h4>
                                 <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                 <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                         </div>
                         </div>                          
                     </div>     
                     <div class="row mt-3 ">
                         <div class="col-md-12 " style='margin-left:44%;'>
                             <p class="slider-button  mt-2 " >
                                 <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a>
                             </p>  
                         </div>
                     </div>          
                 </div>
                 <div class="carousel-item">
                     <div class="row">
                         <div class="col-md-3">
                         <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens11.jpg" alt="Card image cap">
                                 <div class="card-body ">
                                     <div  class='circle' style="background-color:gray;"> &nbsp;&nbsp;</div> 
                                 <span >
                                     Diamond Gray                     
                                 </span>
                                 <h4 class='text-center text-info'>$ 15.00</h4>
                                 <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                 <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                         </div>                  
                         </div>
                         <div class="col-md-3">
                             <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens12.jpg" alt="Card image cap">                       
                                 <div class="card-body ">
                                     <span  class='circle' style="background-color:cornflowerblue;"> &nbsp;&nbsp;</span> 
                                 <span >
                                     Diamond Brown                     
                                 </span>
                                 <h4 class='text-center text-info'>$ 15.00</h4>
                                 <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                 <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                         </div>
                         </div>
                         <div class="col-md-3">
                             <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens13.jpg" alt="Card image cap">
                                 <div class="card-body ">
                                     <span  class='circle'  style="background-color:rgb(207, 100, 166);"> &nbsp;&nbsp;</span> 
                                 <span >
                                     Crystal Pink                
                                 </span>
                                 <h4 class='text-center text-info'>$ 15.00</h4>
                                 <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                 <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                         </div>
                         </div>
                         <div class="col-md-3">
                             <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens15.jpg" alt="Card image cap">
                                 <div class="card-body ">
                                     <span  class='circle'  style="background-color:blue;"> &nbsp;&nbsp;</span> 
                                 <span >
                                     Crystal Blue                    
                                 </span>
                                 <h4 class='text-center text-info'>$ 15.00</h4>
                                 <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                 <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                         </div>
                         </div>                          
                     </div>     
                     <div class="row mt-3 ">
                         <div class="col-md-12 " style='margin-left:44%;'>
                             <p class="slider-button  mt-2 " >
                                 <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a></p>  
                         </div>
                     </div>     
                 </div>
                 <div class="carousel-item">
                     <div class="row">
                         <div class="col-md-3">
                         <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens6.jpg" alt="Card image cap">
                                 <div class="card-body ">
                                     <div  class='circle' style="background-color:gray;"> &nbsp;&nbsp;</div> 
                                 <span >
                                     Diamond Gray                     
                                 </span>
                                 <h4 class='text-center text-info'>$ 15.00</h4>
                                 <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                 <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                         </div>                  
                         </div>
                         <div class="col-md-3">
                             <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens16.jpg" alt="Card image cap">                       
                                 <div class="card-body ">
                                     <span  class='circle' style="background-color:cornflowerblue;"> &nbsp;&nbsp;</span> 
                                 <span >
                                     Diamond Brown                     
                                 </span>
                                 <h4 class='text-center text-info'>$ 15.00</h4>
                                 <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                 <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                         </div>
                         </div>
                         <div class="col-md-3">
                             <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens8.jpg" alt="Card image cap">
                                 <div class="card-body ">
                                     <span  class='circle'  style="background-color:rgb(207, 100, 166);"> &nbsp;&nbsp;</span> 
                                     <span >
                                         Crystal Pink                
                                     </span>
                                     <h4 class='text-center text-info'>$ 15.00</h4>
                                     <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                     <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                             </div>
                         </div>
                         <div class="col-md-3">
                             <div class="card slider-card">                   
                                 <img class="card-img-top" src="vendors/images/color_lens9.jpg" alt="Card image cap">
                                 <div class="card-body ">
                                     <span  class='circle'  style="background-color:blue;"> &nbsp;&nbsp;</span> 
                                     <span>
                                         Crystal Blue                    
                                     </span>
                                     <h4 class='text-center text-info'>$ 15.00</h4>
                                     <span> DIA &nbsp; &nbsp;: 14.2 mm</span><br/>
                                     <span> PWR  : -0.00 to -8.00</span> 
                                 </div>                     
                             </div>
                         </div>                          
                     </div>     
                     <div class="row mt-3 ">
                         <div class="col-md-12" style='margin-left:44%;'>
                             <p class="slider-button  mt-2 " >
                                 <a href="#">See More <i class="fa fa-arrow-right" aria-hidden="true"></i></a></p>  
                         </div>
                     </div>   
                 </div>
             </div>
             <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">              
                 <i class="fa fa-arrow-left left-link-icon" aria-hidden="true"></i>
             </a>
             <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">                            
             <i class="fa fa-arrow-right right-link-icon" aria-hidden="true"></i>                       
             </a>
         </div>           
      </div>
     </div>
  </section><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/frontend/new_collection.blade.php ENDPATH**/ ?>