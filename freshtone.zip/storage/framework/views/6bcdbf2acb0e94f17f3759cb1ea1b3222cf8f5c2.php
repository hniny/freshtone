

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
  <div class="card">
    <div class="card-header bg-dark">
      Edit Accessory Category Name
    </div>
    <div class="card-body">
      <form action="/accessory_categories/<?php echo e($accessory_category->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>       
        <div class="form-group">
          <label for="exampleFormControlInput1"> Accessory Category Name</label>
          <input type="text" class="form-control" name="name" value="<?php echo e($accessory_category->name); ?>">
        </div>        
  
        <div class="form-group">           
              <a href="<?php echo e(URL::previous()); ?>" class="btn btn-secondary">Cancel</a>
              <button type="submit" class="btn btn-primary">Update</button>           
        </div>
      </form>
    </div>
  </div>   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/backend/accessory_category/edit.blade.php ENDPATH**/ ?>