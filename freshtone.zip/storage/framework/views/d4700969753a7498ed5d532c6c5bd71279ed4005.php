
<?php $__env->startSection('content'); ?>
<div class="container-fluid bg-dark">
    <div class="row">
        <div class="col-md-12 p-5 link-bg-color">
            <h1 class="text-white text-center">SAFETY</h1>
        </div>
    </div>  
</div>
<div class="container">
    <div class="row my-4">
        <div class="col-md-6 ">
            <h3 class='title-color text-info'>
                SAFETY & COMFORT
            </h3>
            <p class='text-justify'>
                FRESHTONE CONTACT LENSES INCORPORATE COLOR SANDWICH PROCESSING TECHNOLOGY ENSURING THAT THE COLORED LAYER IS COMPLETELY COATED WITHIN THE LENS THIS PREVENTS DIRECT CONTACT WITH THE EYES ENSURING SAFETY, COMFORT AND EASE OF USE THE LENS ARE SHAPED TO LET THE NATURAL MOISTURE PRODUCED IN THE EYE DIVIDE AND FLOW OVER THE LENS SURFACE EVENLY, PROVIDING ALL DAY COMFORT THE COLORED PORTION OF THE LENS IS PROPORTIONED TO PERFECTION AND ITS STRUCTURE ALLOW THE LENS TO RADIATE A BRIGHTER AND MORE NATURAL LOOK WHILE NOT AFFECTING CLARITY OF THE SIGHT.
            </p>
            <!-- panel-group -->          
            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                <div class="panel panel-default">
                    <div class="panel-heading " role="tab" id="headingOne">
                        <h4 class="panel-title">
                            <a role="button" data-toggle="collapse"  data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"
                            >
                                <i class="more-less fa fa-plus"></i>
                                <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                                soft contact lenses are best for dry eyes
                            </a>
                        </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            THE BEST CONTACT LENSES FOR DRY EYES ARE SOFT CONTACT LENSES, AS OPPOSED TO RIGID ONES. SOFT CONTACTS HAVE BEEN DEVELOPED OVER THE LAST FEW DECADES AND MADE OF SPECIAL POLYMERS, OR PLASTICS, THAT ACTUALLY ALLOW THE LENSES THEMSELVES TO HOLD WATER. THESE SOFT POLYMERS ALSO ARE PERMEABLE, ALLOWING OXYGEN TO PASS THROUGH, QUITE LITERALLY LETTING YOUR EYES BREATHE. THE CORNEA HAS TO RECEIVE OXYGEN THROUGH THE AIR, AS IT HAS NO BLOOD VESSELS OF ITS OWN. CONSEQUENTLY, OXYGEN PERMEABILITY IS AN EXTREMELY IMPORTANT CHARACTERISTIC OF CONTACT LENSES, ESPECIALLY CONTACT LENSES FOR DRY EYES.
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingTwo">
                        <h4 class="panel-title">
                            <a class="collapsed " role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                <i class="more-less fa fa-plus"></i>
                                <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                                water content makes a difference
                            </a>
                        </h4>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                        <div class="panel-body">
                            THE WATER CONTENT OF A SOFT CONTACT LENS CAN VARY GREATLY, FROM 38% WATER TO OVER 70% WATER, SO CONSULT WITH YOUR EYE DOCTOR TO BE SURE YOU’RE USING THE CONTACTS THAT ARE BEST FOR YOU. COUNTERINTUITIVELY, SOFT CONTACTS WITH A HIGHER “WETNESS” LEVEL, THOUGH COMFORTABLE, MAY WORSEN YOUR DRY EYE SYMPTOMS. CONTACTS DESIGNED TO HOLD 65% WATER, FOR EXAMPLE, WILL WICK AWAY MOISTURE FROM WHATEVER ENVIRONMENT THEY ARE IN—IN THIS CASE, YOUR ALREADY-DRY EYES—TO MAINTAIN THAT 65% LEVEL OF MOISTURE. WHILE THE LENSES WILL BE NICE AND MOIST, THIS WILL LEAVE YOUR EYES DRIER THAN THEY WERE BEFORE. A SOFT CONTACT WITH A LOW WATER CONTENT LEVEL OF ABOUT 38% WILL FEEL COMFORTABLE AND ALLOW YOUR EYES TO BREATHE WITHOUT DRYING THEM OUT.
                        </div>
                    </div>
                </div>                   
            </div>  <!-- end panel-group -->          
        </div>
        <div class="col-md-6 mr-0 pr-0">   
           <img src="image/solution.png" height="400px" width="100%">         
        </div>
    </div>
</div>  
 <!-- contact -->
 <section class='mt-3'>
    <div class="container">
        <div class="row my-2" >
            <div class="col-md-5 mt-2">                   
                <ul style='list-style-type:none;margin-left: -40px;'>
                    <li> <h5>CONTACT</h5></li>
                    <li>
                        <i class="fa fa-address-book" aria-hidden="true"></i>
                        No.(121), 1st Floor, Corner of Thein Phyu Rd. and Merchant Rd., (Opposite of Myanmar Five Star Line), Botahtaung Tsp., Yangon Myanmar.
                    </li>
                    <li>
                        <i class="fa fa-mobile" aria-hidden="true">
                            +959 5152274
                        </i>
                    </li>
                    <li>
                        <i class="fa fa-envelope" aria-hidden="true"></i>                           
                        freshtone.myanmar@gmail.com
                    </li>
                    <li></li>
                </ul>
                <p style="margin-left: 2.5rem;">
                     <i class="fa fa-facebook-official " aria-hidden="true"></i>
                    <i class="fa fa-instagram ml-2" aria-hidden="true"></i>
                    <i class="fa fa-twitter ml-2" aria-hidden="true"></i>
                    <i class="fa fa-link  ml-2" aria-hidden="true"></i>
                </p>                  
            </div>
            <div class="col-md-3  mt-2">
                <ul style='list-style-type:none;'>
                    <li> <h5>QUICK LINK</h5></li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>
                        <a href="#"> Home</a>
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>
                        <a href="#"> Contact Lens</a>
                            
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>                          
                        <a href="#"> Accessories</a>
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>                          
                        <a href="#"> Eye Mask</a>
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>                          
                        <a href="#"> Eye Care</a>
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>                          
                        <a href="#"> Safety</a>
                    </li>
                    <li>
                        <i class="fa fa-arrow-right" aria-hidden="true"></i>                          
                        <a href="#"> Contact Us</a>
                    </li>                       
                </ul>
            </div>
            <div class="col-md-4 m-0 p-0 mt-2">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3820.09447236042!2d96.16486161423276!3d16.771974788450123!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c1ed4c2195b60d%3A0x790bedd11a54b370!2sFreshToneMyanmar!5e0!3m2!1sen!2smm!4v1581305963661!5m2!1sen!2smm" width="100%" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            </div>
        </div>
    </div>
 </section>
<!-- end contact  -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<style>
 
    .panel-default > .panel-heading {
        padding: 0;
        border-radius: 11px;
        color: #212121;
        background-color: #d5f3fe;
        border-color:#d5f3fe;
    }
    .panel-title {
        font-size: 20px;
    }
    .panel-title > a {
        display: block;
        padding: 15px;
        text-decoration: none;
    }
    .more-less{
        float: right;
    }
    .panel-default > .panel-heading + .panel-collapse > .panel-body {
        border-top-color: #EEEEEE;
    }
    .bg a {
        background-color: #2d62a8 ;
        color: #fff ;      
        border-radius: 11px;
    } 
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
   
    function toggleIcon(e) {
        // console.log('e',e);
        $(e.target)
            .prev('.panel-heading')    
            .toggleClass('bg')  
            .find(".more-less")              
            .toggleClass('fa-plus fa-minus');               
     
        
    }
    $('.panel-group').on('hidden.bs.collapse', toggleIcon);
    $('.panel-group').on('shown.bs.collapse', toggleIcon);
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/frontend/safety.blade.php ENDPATH**/ ?>