

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>   
  <div class="card">
    <div class="card-header bg-dark">
    Create Len Item
    </div>
    <div class="card-body">
    <form action="/len_items" method="post" class="needs-validation"  novalidate enctype="multipart/form-data">
      <?php echo csrf_field(); ?>      
      <div class="form-group">
        <label for="exampleFormControlSelect2">Select Len Category</label>
        <select id="len_category_id"  name="len_category_id" class="form-control"  required>
          <option value="0">Default </option> 
          <?php $__currentLoopData = $len_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $len_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($len_category->id); ?>"><?php echo e($len_category->category_name); ?></option>       
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </select>
        <div class="invalid-feedback">
          Enter Len Category
        </div>
      </div>        
      <div class="form-group">
        <label for="exampleFormControlInput1">Item  Name</label>
        <input type="text" class="form-control" id="item_name" name="item_name" required>
        <div class="invalid-feedback">
          Enter Item  Name
        </div> 
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Price</label>
        <input type="number" class="form-control" name="price" required>
        <div class="invalid-feedback">
          Enter Item  Price
        </div> 
      </div>          
      <div class="form-group">
        <label for="exampleFormControlTextarea1">Description</label>       
        <textarea name="description" id="description" class="form-control description" rows="5" cols="5" required></textarea>
        <div class="invalid-feedback">
          Enter Item Description
        </div>
      </div>
      <div class="form-group">
        <label for="exampleFormControlTextarea1">Len Item Image</label>    
        <br/>          
          <input type="file" name='item_image' class="mb-2" onchange="preview(event)">
          <br/>
          <img id="img" width="200px">       
        <div class="invalid-feedback">
          Enter Item Image 
        </div>
      </div>
      <div class="form-group">           
          <a href="/len_items" class="btn btn-secondary">Cancel</a>
          <button type="submit" class="btn btn-primary">Save</button>           
      </div>
      </form>  
    </div>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>    
<script src="<?php echo e(asset('vendors/js/validation.js')); ?>"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.description').summernote();
  });
  function preview(event){
    var input=event.target.files[0];
    var reader=new FileReader();
    reader.onload=function(){
      var result=reader.result;
      var img=document.getElementById('img');
      img.src=result;
    }
    reader.readAsDataURL(input);    
  }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\HMM\projects\freshtone\resources\views/backend/len_item/create.blade.php ENDPATH**/ ?>