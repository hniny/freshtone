

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header bg-dark">
    Edit Len Item
  </div>
  <div class="card-body">
    <form action="/len_items/<?php echo e($len_item->id); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>      
      <div class="form-group">
        <label for="exampleFormControlInput1">Len Category Name</label>
        <select name="len_category_id" class="form-control" id="exampleFormControlSelect2">
          <option value="0">Default </option> 
          <?php $__currentLoopData = $len_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $len_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($len_category->id); ?>" <?php if($len_category->id==$len_item->len_category_id): ?> selected <?php endif; ?>><?php echo e($len_category->category_name); ?></option>       
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </select>
      </div>      
      <div class="form-group">
        <label for="exampleFormControlInput1">Item  Name</label>
        <input type="text" class="form-control" id="item_name" name="item_name" value="<?php echo e($len_item->item_name); ?>" required>
        <div class="invalid-feedback">
          Enter Item  Name
        </div> 
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Price</label>
        <input type="number" class="form-control" name="price" value="<?php echo e($len_item->price); ?>" required>
        <div class="invalid-feedback">
          Enter Item  Price
        </div> 
      </div>          
      <div class="form-group">
        <label for="exampleFormControlTextarea1">Description</label>       
        <textarea name="description" id="description" class="form-control description" rows="5" cols="5" required><?php echo e($len_item->description); ?></textarea>
        <div class="invalid-feedback">
          Enter Item Description
        </div>
      </div>
      <div class="form-group">       
        <label for="exampleFormControlTextarea1">Len Item Image</label>    
        <div class="row">          
          <div class="col-md-2">            
            <img src="<?php echo e(url('image/'.$len_item->item_image)); ?>" data-src="<?php echo e($len_item->item_image); ?>"  width="115px" height="100px" id="item_image" data-toggle="modal" data-target="#exampleModal"/>             
            <div class="modal fade" id="exampleModal" style="top: 20%;" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document" style='width: 340px;' >
              <div class="modal-content text-center">                                        
                  <div class="modal-body">
                  <img src="<?php echo e(url('image/'.$len_item->item_image)); ?>" data-src="<?php echo e($len_item->item_image); ?>"  width="300px"  height="230px" id="item_image" data-toggle="modal" data-target="#exampleModal"/>  
                  </div>   
                  <button type="button" class="close close-button"   data-dismiss="modal" aria-label="Close" style="margin-bottom: 15px;">
                      <i class="fa fa-times-circle"   aria-hidden="true"></i>
                  </button>             
              </div>
              </div>
          </div>    
            <input type="hidden" name="old_image" value="<?php echo e($len_item->item_image); ?>"  />
          </div>
          <div class="col-md-10">
            <input type="file" name='item_image'>
            <div class="invalid-feedback">
              Enter Item Image 
            </div>     
          </div>
        </div>            
      </div>
      <div class="form-group">           
            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary">Update</button>           
      </div>
  </form> 
  </div>
</div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="vendors/css/style.css">   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> 
    $(document).ready(function(){
      $('.description').summernote();     
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\hmm\freshtone\freshtone\resources\views/backend/len_item/edit.blade.php ENDPATH**/ ?>